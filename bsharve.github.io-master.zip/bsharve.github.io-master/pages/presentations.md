---
layout: page
title: Presentations
description: Student's Presentations in Data Analytics
---


###  2017

#### EMSE 6992 Final Project: {Enter Title Here}
<br/>&nbsp; &nbsp; &nbsp; Slides:
[![pdf](icons16/pdf-icon.png)](https://www.biostat.wisc.edu/~kbroman/presentations/SGN2017/sgn2017.pdf)
[![github](icons16/github-icon.png)](https://github.com/kbroman/Talk_SGN2017)<br/>
&nbsp; &nbsp; &nbsp; 

---




