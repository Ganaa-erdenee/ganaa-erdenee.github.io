---
layout: page
title: about
description: Benjamin Harvey is...
---

#### <a name="currentposition"></a>current position
{Insert text here}


#### <a name="previousposition"></a>previous positions
{Insert text here}


#### <a name="researchbackground"></a>research background
{Insert text here}


#### <a name="education"></a>ecucation
{Insert text here}


#### <a name="cvandresume"></a>cv and resume
[curriculum vitae ![CV as pdf](icons16/pdf-icon.png)]({{ BASE_PATH }}/assets/bsharvey_cv.pdf)

---



