---
layout: frontpage
title: Broman and Sen (2009)
---

<div class="navbar">
  <div class="navbar-inner">
      <ul class="nav">
          <li><a href="isletc6_fig4.html">prev</a></li>
          <li><a href="rqtlexper_fig1.html">next</a></li>
      </ul>
  </div>
</div>

**Broman KW**, Sen &#346; (2009) A Guide to QTL Mapping with R/qtl.  Springer, New York
[![Online complements](../icons16/html-icon.png)](http://www.rqtl.org/book)
[![Amazon](../icons16/amazon-icon.png)](https://www.amazon.com/gp/product/0387921249?ie=UTF8&tag=7210-20)
[![Springer](../icons16/springer-icon.png)](http://www.springer.com/978-0-387-92124-2)
[![R/qtl](../icons16/R-icon.png)](http://www.rqtl.org)

![Broman and Sen (2009) cover](../../assets/publpics/rqtlbook_cover.jpg)
{:.center}
